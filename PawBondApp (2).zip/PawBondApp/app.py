from flask import Flask, render_template, request, redirect, url_for, flash
from flask_mysqldb import MySQL 
import datetime

app = Flask(__name__) 
app.secret_key = 'mi_clave_secreta_super_segura' 

# CONFIGURACIÓN DE LA BASE DE DATOS
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'pawbond'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app) 

@app.route('/')
def listar_mascotas():
    mascotas = []
    publicaciones = []
    
    try:
        cur = mysql.connection.cursor() 
        
        query_mascotas = """
        SELECT
            m.nombreMascota,
            m.especie,
            m.raza,
            m.edad,
            m.genero,
            m.color,
            u.nombre AS nombreDueno,
            u.telefono AS telefonoDueno,
            c.estadoCollar
        FROM
            mascota m
        JOIN
            usuario u ON m.idUsuario = u.idUsuario
        LEFT JOIN
            collar c ON m.idMascota = c.idMascota;
        """
        cur.execute(query_mascotas)
        mascotas = cur.fetchall()
        
        query_publicaciones = """
        SELECT
            p.Comentario,
            p.FechaPublicacion,
            u.nombre AS nombreUsuario
        FROM
            publicacion p
        JOIN
            usuario u ON p.idUsuario = u.idUsuario
        ORDER BY
            p.FechaPublicacion DESC;
        """
        cur.execute(query_publicaciones)
        publicaciones = cur.fetchall()
        
        cur.close()
        
    except Exception as e:
        print(f"Error al listar datos: {e}")
        flash('Error al cargar datos de la base de datos.', 'error')
        
    return render_template('index.html', mascotas=mascotas, publicaciones=publicaciones)


@app.route('/publicar', methods=['POST'])
def publicar_alerta():
    if request.method == 'POST':
        nombre_u = request.form['nombreUsuario']
        comentario = request.form['comentario']
        
        try:
            cur = mysql.connection.cursor() 
           
            cur.execute("SELECT idUsuario FROM usuario WHERE nombre = %s", (nombre_u,))
            usuario_data = cur.fetchone() 
            
            if not usuario_data:
                flash(f'Error: El usuario "{nombre_u}" no está registrado.', 'error')
                cur.close()
                return redirect(url_for('listar_mascotas'))
            
            id_usuario = usuario_data['idUsuario'] 
            
            query_publicacion = """
            INSERT INTO publicacion (idUsuario, Comentario) 
            VALUES (%s, %s)
            """
            cur.execute(query_publicacion, (id_usuario, comentario))
            
           
            mysql.connection.commit() 
            cur.close()
            
            flash('¡Alerta publicada exitosamente!', 'success')
            
        except Exception as e:
            mysql.connection.rollback()
            print(f"Error al publicar alerta: {e}")
            flash('Error interno al publicar la alerta.', 'error')
        
        return redirect(url_for('listar_mascotas'))


@app.route('/registrar_usuario', methods=['POST'])
def registrar_usuario():
    if request.method == 'POST':
        try:
            cur = mysql.connection.cursor()
            
            nombre_u = request.form['nombre']
            correo_u = request.form['correo']
            clave_u = request.form['clave'] 
            doc_u = request.form['documento']
            tel_u = request.form['telefono']
            dir_u = request.form['direccion']
            
            
            query_usuario = """
            INSERT INTO usuario (nombre, correo, contraseña, numeroDocumento, telefono, direccion, fechaRegistro) 
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            fecha_registro = datetime.datetime.now()
            cur.execute(query_usuario, (nombre_u, correo_u, clave_u, doc_u, tel_u, dir_u, fecha_registro))
            
            mysql.connection.commit()
            cur.close()
            
            flash(f'¡Registro de usuario exitoso! Bienvenido/a {nombre_u}.', 'success')
            
        except Exception as e:
            mysql.connection.rollback() 
            print(f"Error durante el registro de usuario: {e}")
            flash(f'Error al registrar el usuario: {e}', 'error')
        
        return redirect(url_for('listar_mascotas'))


@app.route('/registrar_mascota', methods=['POST'])
def registrar_mascota():
    if request.method == 'POST':
        nombre_u = request.form['nombreDueno']
        
        nombre_m = request.form['nombreMascota']
        raza_m = request.form['raza']
        edad_m = request.form['edad']
        genero_m = request.form['genero']
        especie_m = request.form['especie']
        color_m = request.form['color']
        esterilizado_m = request.form.get('esterilizado', 'No') 
        
        try:
            cur = mysql.connection.cursor() 
            
            cur.execute("SELECT idUsuario FROM usuario WHERE nombre = %s", (nombre_u,))
            usuario_data = cur.fetchone() 
            
            if not usuario_data:
                flash(f'Error: El dueño "{nombre_u}" no está registrado. Regístrese primero.', 'error')
                cur.close()
                return redirect(url_for('listar_mascotas'))
            
            id_usuario = usuario_data['idUsuario'] 
            
            query_mascota = """
            INSERT INTO mascota (idUsuario, nombreMascota, raza, edad, genero, especie, color)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            cur.execute(query_mascota, (id_usuario, nombre_m, raza_m, edad_m, genero_m, especie_m, color_m))

            mysql.connection.commit()
            cur.close()
            
            flash(f'¡Mascota {nombre_m} registrada exitosamente!', 'success')
            
        except Exception as e:
            mysql.connection.rollback()
            print(f"Error al registrar mascota: {e}")
            flash('Error interno al registrar la mascota.', 'error')
        
        return redirect(url_for('listar_mascotas'))


if __name__ == '__main__':
    app.run(debug=True)