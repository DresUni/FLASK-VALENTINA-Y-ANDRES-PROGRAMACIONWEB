-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-11-2025 a las 21:56:52
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pawbond`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `collar`
--

CREATE TABLE `collar` (
  `idCollar` int(11) NOT NULL,
  `idMascota` int(11) NOT NULL,
  `estadoCollar` enum('activo','inactivo') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `collar`
--

INSERT INTO `collar` (`idCollar`, `idMascota`, `estadoCollar`) VALUES
(7, 13, 'activo'),
(8, 15, 'activo'),
(9, 14, 'inactivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `infomedica`
--

CREATE TABLE `infomedica` (
  `idInfo` int(11) NOT NULL,
  `idMascota` int(11) DEFAULT NULL,
  `peso` text DEFAULT NULL,
  `medicamentosActuales` text DEFAULT NULL,
  `alergias` text DEFAULT NULL,
  `enfermedades` text DEFAULT NULL,
  `vacunas` text DEFAULT NULL,
  `fechaUltimaVacuna` date DEFAULT NULL,
  `esterilizado` enum('Si','No') DEFAULT NULL,
  `infoAdicional` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `infomedica`
--

INSERT INTO `infomedica` (`idInfo`, `idMascota`, `peso`, `medicamentosActuales`, `alergias`, `enfermedades`, `vacunas`, `fechaUltimaVacuna`, `esterilizado`, `infoAdicional`) VALUES
(1, 13, '28.5', 'Ninguno', 'Ninguna conocida', 'Displasia de cadera (leve)', 'Si', '2025-09-15', 'Si', 'Necesita caminatas cortas; reacciona bien a caricias.'),
(2, 15, '4.2', 'Metronidazol', 'Alergia al pollo', 'Problemas digestivos crónicos', 'Si', '2025-07-20', 'Si', 'Dieta estricta sin proteínas de ave. Muy asustadiza.'),
(3, 14, '3.5', 'Ninguno', 'Aspirina', 'Ninguna conocida', 'Si', '2025-10-01', 'No', 'Necesita bebedero bajo. Muy social y juguetona.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascota`
--

CREATE TABLE `mascota` (
  `idMascota` int(11) NOT NULL,
  `nombreMascota` varchar(100) NOT NULL,
  `raza` varchar(50) NOT NULL,
  `edad` int(11) NOT NULL,
  `genero` enum('Macho','Hembra') DEFAULT NULL,
  `especie` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `fechaRegistroMascota` datetime DEFAULT current_timestamp(),
  `idUsuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mascota`
--

INSERT INTO `mascota` (`idMascota`, `nombreMascota`, `raza`, `edad`, `genero`, `especie`, `color`, `fechaRegistroMascota`, `idUsuario`) VALUES
(13, 'Max', 'Golden Retriever', 4, 'Macho', 'Perro', 'Dorado', '2025-01-25 00:00:00', 5),
(14, 'Luna', 'Siamés', 2, 'Hembra', 'Gato', 'Crema y Marrón', '2024-11-10 00:00:00', 6),
(15, 'Coco', 'Poodle Toy', 6, 'Hembra', 'Perro', 'Blanco', '2025-03-05 00:00:00', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicacion`
--

CREATE TABLE `publicacion` (
  `idPublicacion` int(11) NOT NULL,
  `idUsuario` int(11) DEFAULT NULL,
  `Comentario` text NOT NULL,
  `FechaPublicacion` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `publicacion`
--

INSERT INTO `publicacion` (`idPublicacion`, `idUsuario`, `Comentario`, `FechaPublicacion`) VALUES
(1, 4, '¡Alerta! Mi perro Max fue visto cerca del parque central. Collar NFC activo.', '2025-11-15 15:30:00'),
(2, 5, 'Encontré un gato Siamés con collar NFC en la Calle 5. Contacté al dueño, estoy esperando respuesta.', '2025-11-15 16:10:00'),
(3, 6, 'Busco a mi Poodle Coco. Se perdió hace una hora, por favor escanear el chip si la ven.', '2025-11-15 17:45:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reporte`
--

CREATE TABLE `reporte` (
  `idReporte` int(11) NOT NULL,
  `idCollar` int(11) DEFAULT NULL,
  `ubicacion` varchar(50) NOT NULL,
  `descripcionReporte` text NOT NULL,
  `infoContactoReporte` varchar(50) NOT NULL,
  `fechaReporte` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reporte`
--

INSERT INTO `reporte` (`idReporte`, `idCollar`, `ubicacion`, `descripcionReporte`, `infoContactoReporte`, `fechaReporte`) VALUES
(1, 13, 'Parque Nacional', 'Vi al Golden Retriever en un parque, está tranquilo pero solo. Escaneo realizado con éxito.', 'Pedro Gómez (3105551234)', '2025-11-15 16:00:00'),
(2, 15, 'La Candelaria', 'Gato Siamés encontrado en un callejón. Parece asustado y desorientado. Dejé comida.', 'Maria Rojas (mrojas@ejemplo.com)', '2025-11-15 17:35:00'),
(3, 14, 'Barrio Galerías', 'El Poodle Toy fue visto subiendo a un bus cerca de la estación. Contacto al dueño automático.', 'Sistema Automático NFC', '2025-11-15 18:05:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(120) DEFAULT NULL,
  `contraseña` varchar(255) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `numeroDocumento` varchar(20) DEFAULT NULL,
  `fechaRegistro` datetime DEFAULT current_timestamp(),
  `direccion` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idUsuario`, `nombre`, `correo`, `contraseña`, `telefono`, `numeroDocumento`, `fechaRegistro`, `direccion`) VALUES
(4, 'Laura Perez', 'laura@gmail.com', '123456', 2147483647, '10255378954', '2025-02-14 00:00:00', 'Calle 10 # 5-51'),
(5, 'Carlitos Gutierrez', 'carlos@gmail.com', 'abc123', 2147483647, '1028695874', '2025-11-14 00:00:00', 'Calle 10 # 5-51'),
(6, 'Luisito Comunica', 'luisito@gmail.com', 'abc123', 2147483647, '5228656950', '2024-12-10 00:00:00', 'Carrera 21 # 17-63');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `collar`
--
ALTER TABLE `collar`
  ADD PRIMARY KEY (`idCollar`),
  ADD KEY `pertenece` (`idMascota`);

--
-- Indices de la tabla `infomedica`
--
ALTER TABLE `infomedica`
  ADD PRIMARY KEY (`idInfo`);

--
-- Indices de la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD PRIMARY KEY (`idMascota`),
  ADD KEY `tiene` (`idUsuario`);

--
-- Indices de la tabla `publicacion`
--
ALTER TABLE `publicacion`
  ADD PRIMARY KEY (`idPublicacion`);

--
-- Indices de la tabla `reporte`
--
ALTER TABLE `reporte`
  ADD PRIMARY KEY (`idReporte`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idUsuario`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD UNIQUE KEY `numeroDocumento` (`numeroDocumento`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `collar`
--
ALTER TABLE `collar`
  MODIFY `idCollar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `infomedica`
--
ALTER TABLE `infomedica`
  MODIFY `idInfo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `mascota`
--
ALTER TABLE `mascota`
  MODIFY `idMascota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `publicacion`
--
ALTER TABLE `publicacion`
  MODIFY `idPublicacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `reporte`
--
ALTER TABLE `reporte`
  MODIFY `idReporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `collar`
--
ALTER TABLE `collar`
  ADD CONSTRAINT `pertenece` FOREIGN KEY (`idMascota`) REFERENCES `mascota` (`idMascota`);

--
-- Filtros para la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD CONSTRAINT `tiene` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
