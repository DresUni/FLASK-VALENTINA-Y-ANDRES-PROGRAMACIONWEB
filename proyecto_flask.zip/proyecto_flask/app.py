from flask import Flask, render_template, request, redirect, url_for, flash
from flask_mysqldb import MySQL 


app = Flask(__name__) 
app.secret_key = 'mi_clave_secreta_super_segura' 

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'crud_flask' 
mysql = MySQL(app) 


@app.route('/')
def index(): 
    """Ruta para Leer/Mostrar todos los usuarios (Read) desde MySQL."""
    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT idUsuario, nombre, correo, telefono, cumpleaños FROM usuarios') 
        data = cur.fetchall() 
        cur.close()

        column_names = ['id', 'nombre', 'correo', 'telefono', 'cumpleanos'] 
        usuarios = [dict(zip(column_names, row)) for row in data]
        
        return render_template('index.html', usuarios=usuarios)
    except Exception as e:
        flash(f'Error al conectar o leer la base de datos: {e}', 'danger')
        return render_template('index.html', usuarios=[])


@app.route('/administrador')
def administrador():
    """
    Ruta para el panel de administración.
    Permite listar todos los usuarios y, opcionalmente, entrar en modo de edición 
    para un usuario específico usando el parámetro 'editar' en la URL.
    """
    try:
   
        id_para_editar = request.args.get('editar', None, type=int)

        cur = mysql.connection.cursor()
     
        cur.execute('SELECT idUsuario, nombre, correo, telefono, cumpleaños, comentario FROM usuarios')
        usuarios_data = cur.fetchall()
        cur.close()
        

        return render_template('administrador.html', usuarios=usuarios_data, id_para_editar=id_para_editar)
        
    except Exception as e:
        flash(f'Error al cargar el panel de administrador: {e}', 'danger')
        return render_template('administrador.html', usuarios=[], id_para_editar=None)



@app.route('/agregar')
def agregar_usuario_form():
    """Muestra la plantilla con el formulario para agregar un nuevo usuario."""
    return render_template('agregar.html')

@app.route('/add_usuario', methods=['POST'])
def add_usuario():
    """Ruta para procesar el formulario (Create) hacia MySQL."""
    if request.method == 'POST':
        
        nombre = request.form.get('nombre')
        correo = request.form.get('correo')
        telefono = request.form.get('telefono')
        cumpleanos = request.form.get('cumpleanos')
        
        comentario = request.form.get('comentario', '') 

        if not all([nombre, correo, telefono, cumpleanos]):
            flash('Error: El formulario no envió todos los campos esperados.', 'danger')
            return redirect(url_for('agregar_usuario_form'))
        
        try:
            cur = mysql.connection.cursor()
           
            cur.execute("""
                INSERT INTO usuarios (nombre, correo, telefono, cumpleaños, comentario) 
                VALUES (%s, %s, %s, %s, %s)
            """, (nombre, correo, telefono, cumpleanos, comentario)) 
           

            mysql.connection.commit()
            cur.close()
            flash('¡Usuario agregado correctamente a la base de datos!', 'success')
        
        except Exception as e:
          
            flash(f'Error al insertar el usuario: {e}', 'danger')

        return redirect(url_for('index'))
    
    return redirect(url_for('agregar_usuario_form'))

@app.route('/update/<int:id_usuario>', methods=['POST'])
def update_usuario(id_usuario):
    """Procesa la actualización de un usuario desde la tabla de administrador."""
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        correo = request.form.get('correo')
        telefono = request.form.get('telefono')
        cumpleanos = request.form.get('cumpleanos')
        comentario = request.form.get('comentario', '') 

        try:
            cur = mysql.connection.cursor()
            cur.execute("""
                UPDATE usuarios 
                SET nombre = %s, correo = %s, telefono = %s, cumpleaños = %s, comentario = %s
                WHERE idUsuario = %s
            """, (nombre, correo, telefono, cumpleanos, comentario, id_usuario))
            
            mysql.connection.commit()
            cur.close()
            flash(f'¡Usuario ID {id_usuario} actualizado correctamente!', 'success')
        
        except Exception as e:
            flash(f'Error al actualizar el usuario: {e}', 'danger')

        return redirect(url_for('administrador'))

@app.route('/delete/<int:id_usuario>')
def delete_usuario(id_usuario):
    """Elimina un usuario por su ID."""
    try:
        cur = mysql.connection.cursor()
        cur.execute('DELETE FROM usuarios WHERE idUsuario = %s', (id_usuario,))
        mysql.connection.commit()
        cur.close()
        flash(f'Usuario ID {id_usuario} eliminado correctamente.', 'success')
    except Exception as e:
        flash(f'Error al eliminar el usuario: {e}', 'danger')
        
    return redirect(url_for('administrador'))


@app.route('/servicios')
def servicios():
    return render_template('servicios.html')

@app.route('/contacto')
def contacto():
    return render_template('contacto.html')

if __name__ == '__main__':
    app.run(debug=True)